﻿namespace SAPRamat
{
    public class Force
    {

    }
}