﻿using System;
using System.Collections.Generic;
using System.Text;
using SAPRamat;

namespace SAPRamat
{
    class Base
    {
    }
}
